package test0326;
/*
3. 동전을 표현하는 Coin 클래스 구현하기
      멤버변수 :  동전의 면(side) //0-앞 1-뒤
      멤버메서드 : void flip() 
           기능 : 동전을 던져 동전의 면을 변경한다. Math.random() 메서드 이용. 
                 앞면,뒷면을 side필드의 값을 변경. 
*/
class Coin{
	int side;
	void flip() {
		side = (int) (Math.random()+1);
	}
}
public class Test5 {
	public static void main(String[] args) {
		Coin coin = new Coin();
		System.out.println(coin.side==0?"앞면":"뒷면");
		coin.flip(); //side필드의 값을 변경시켜줌
		System.out.println(coin.side==0?"앞면":"뒷면");
	}
}
